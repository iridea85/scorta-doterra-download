// In-app messages only: no push, device IDs, telemetry or recipe access.
(() => {
  'use strict';
  const key = 'doterra_app_messages_read_v1';
  let messages = [], read = new Set(), blocked = false, shown = new Set();
  try { const value = JSON.parse(localStorage.getItem(key) || '[]'); if (!Array.isArray(value)) throw Error('invalid'); read = new Set(value.filter(id => Number.isSafeInteger(id) || (typeof id === 'string' && /^[0-9a-f-]{36}$/i.test(id)))); } catch (_) { blocked = true; }
  const style = document.createElement('style');
  style.textContent = `.scorta-message-shade{position:fixed;inset:0;background:#22152988;z-index:1000000;display:grid;place-items:center;padding:16px;font:16px/1.45 system-ui;color:#302637}.scorta-message-box{background:white;border:1px solid #e7dfe8;border-radius:18px;width:min(460px,100%);max-height:85dvh;overflow:auto;padding:22px;box-shadow:0 18px 45px #0003;box-sizing:border-box}.scorta-message-box h2{font-size:22px;margin:8px 0}.scorta-message-box p{white-space:pre-wrap;overflow-wrap:anywhere}.scorta-message-box small{font-size:14px;color:#6e5578}.scorta-message-box button{font:inherit;padding:11px 16px;border:0;border-radius:10px;background:#6e5578;color:white;cursor:pointer}.scorta-message-banner{position:fixed;left:12px;right:12px;top:calc(64px + env(safe-area-inset-top));z-index:99997;background:#eee4f1;color:#302637;border:1px solid #cbbace;border-radius:12px;padding:10px 12px;font:14px/1.35 system-ui;display:flex;align-items:center;gap:10px;box-shadow:0 4px 14px #36263c18}.scorta-message-banner button{font:inherit;color:#60476b;background:white;border:1px solid #d8c9de;padding:8px;border-radius:8px}.scorta-message-banner span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.scorta-message-box article{border-top:1px solid #e8dfeb;margin-top:16px;padding-top:12px}`;
  document.head.append(style);
  function mark(message) {
    read.add(message.id);
    if (!blocked) { try { localStorage.setItem(key, JSON.stringify([...read])); } catch (_) { blocked = true; } }
  }
  function node(tag, text) { const n = document.createElement(tag); if (text) n.textContent = text; return n; }
  function dialog(label) {
    const shade = node('div'); shade.className = 'scorta-message-shade';
    const box = node('section'); box.className = 'scorta-message-box'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', label);
    shade.append(box); document.body.append(shade);
    const before = document.activeElement;
    function close() { shade.remove(); before?.focus?.(); }
    shade.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); box.querySelector('button')?.click(); } if (event.key === 'Tab') { const buttons = [...box.querySelectorAll('button')]; if (buttons.length) { event.preventDefault(); const current = buttons.indexOf(document.activeElement); buttons[(current + (event.shiftKey ? buttons.length - 1 : 1)) % buttons.length].focus(); } } });
    return { shade, box, close };
  }
  function show(message, done = () => {}) {
    if (document.querySelector('.scorta-message-shade')) return;
    const ui = dialog(message.title);
    ui.box.append(node('small', message.kind), node('h2', message.title), node('p', message.body));
    const button = node('button', 'Ho letto'); button.type = 'button';
    button.onclick = () => { mark(message); ui.close(); done(); };
    ui.box.append(button); button.focus();
  }
  function present() {
    if (document.querySelector('.scorta-message-shade') || document.querySelector('#scorta-settings-panel')) return;
    const unread = messages.filter(m => (!m.once || !read.has(m.id)) && !shown.has(m.id));
    const popup = unread.find(m => m.display === 'popup');
    if (popup) { shown.add(popup.id); show(popup, present); return; }
    document.querySelector('.scorta-message-banner')?.remove();
    const banner = unread.find(m => m.display === 'banner');
    if (!banner) return;
    const bar = node('div'); bar.className = 'scorta-message-banner'; bar.setAttribute('role', 'status');
    const open = node('button', 'Leggi'); open.type = 'button'; open.onclick = () => { bar.remove(); shown.add(banner.id); show(banner, present); };
    const dismiss = node('button', '×'); dismiss.type = 'button'; dismiss.setAttribute('aria-label', 'Chiudi messaggio'); dismiss.onclick = () => { shown.add(banner.id); mark(banner); bar.remove(); present(); };
    bar.append(node('span', banner.title), open, dismiss); document.body.append(bar);
  }
  async function refresh() {
    try { const r = await fetch('https://ozgpdglnycmmhilvsqsw.supabase.co/rest/v1/sd_app_messages?select=id,title,body,type,display,show_once,starts_at,ends_at&active=eq.true&order=created_at.desc&limit=50', { cache: 'no-store', credentials: 'omit', headers: { apikey: 'sb_publishable_3VIXsCBHD6ugmcuBkZ4sqA_xuudgE60' } }); if (!r.ok) return; const data = await r.json(); const kinds = { app_updated: 'App aggiornata', catalog_updated: 'Catalogo aggiornato', new_products: 'Nuovi prodotti aggiunti', maintenance: 'Manutenzione', important: 'Informazione importante', free: 'Messaggio libero' }; messages = Array.isArray(data) ? data.map(m => ({ id: m.id, title: m.title, body: m.body, kind: kinds[m.type] || 'Messaggio libero', display: m.display || 'popup', once: m.show_once })) : []; present(); } catch (_) { /* The inventory remains fully usable offline. */ }
  }
  window.scortaOpenMessages = () => {
    if (document.querySelector('.scorta-message-shade')) return;
    const ui = dialog('Messaggi App'); ui.box.append(node('h2', 'Messaggi App'));
    if (!messages.length) ui.box.append(node('p', 'Nessun messaggio attivo.'));
    for (const m of messages) {
      const article = node('article'); article.append(node('small', `${m.kind}${read.has(m.id) ? ' · Letto' : ' · Nuovo'}`), node('h2', m.title), node('p', m.body));
      if (!read.has(m.id)) { const button = node('button', 'Segna come letto'); button.onclick = () => { mark(m); button.textContent = 'Letto'; button.disabled = true; }; article.append(button); }
      ui.box.append(article);
    }
    const close = node('button', 'Chiudi'); close.onclick = ui.close; ui.box.append(close); close.focus();
  };
  document.addEventListener('visibilitychange', () => { if (!document.hidden) void refresh(); });
  window.addEventListener('focus', () => void refresh());
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => void refresh(), { once: true }); else void refresh();
})();
