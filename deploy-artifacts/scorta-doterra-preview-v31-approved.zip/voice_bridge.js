// The browser owns speech recognition and releases the microphone when it ends.
// No audio or transcript is persisted by this bridge.
window.doterraListenOnce = function () {
  return new Promise(resolve => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) return resolve('__ERROR__:Riconoscimento vocale non disponibile in questo browser.');
    const recognition = new Recognition();
    recognition.lang = 'it-IT';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    let settled = false;
    recognition.onresult = event => {
      settled = true;
      resolve(event.results[0][0].transcript);
      recognition.stop();
    };
    recognition.onerror = event => {
      settled = true;
      resolve('__ERROR__:' + (event.error === 'not-allowed' ? 'Permesso microfono negato.' : 'Non sono riuscita ad ascoltare. Riprova.'));
    };
    recognition.onend = () => { if (!settled) resolve('__ERROR__:Non ho sentito un comando.'); };
    try { recognition.start(); }
    catch (_) { resolve('__ERROR__:Impossibile avviare il microfono.'); }
  });
};
window.doterraShareText = async function (text) {
  if (!navigator.share) return false;
  try { await navigator.share({ text }); return true; }
  catch (error) { if (error.name === 'AbortError') return true; throw error; }
};
